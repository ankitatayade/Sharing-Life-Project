package com.organ.donation.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.organ.donation.dto.DonationDTO;
import com.organ.donation.dto.ReceipientDTO;
import com.organ.donation.dto.SignInRequest;
import com.organ.donation.entities.Receipients;
import com.organ.donation.service.ReceipientService;

@RestController
@RequestMapping("/api/receipients")
@CrossOrigin
@Validated
public class ReceipientController {
	@Autowired
	private ReceipientService receipientService;

	//get receiver details
	//http://host:port/receivers
	@GetMapping
	public ResponseEntity<?> getAllReceipients(){
		System.out.println("in get all receiver method");
		return ResponseEntity.ok(receipientService.getAllReceipients());
	}

	//validate login
	@PostMapping("/validate")
	public ResponseEntity<?> validateReciepients(@RequestBody @Valid SignInRequest request){
		System.out.println("in validate receipient method "+request);
		Receipients data = receipientService.validate(request);
		if(data == null) {
			return ResponseEntity.status(404).body("Invalid username or password");
		}
		return ResponseEntity.ok(data);
	}

	//add new receiver details
	@PostMapping
	public ResponseEntity<?> addNewReceipient(@RequestBody @Valid ReceipientDTO receipientDto){
		System.out.println("in add new receiver"+receipientDto);
		return ResponseEntity
				.status(HttpStatus.CREATED)
				.body(receipientService.addNewReceipient(receipientDto));


	}
	
	@PostMapping("/donation")
	public ResponseEntity<?> processDonation(@RequestBody DonationDTO dto){
		receipientService.donationProcess(dto);
		return ResponseEntity.ok("Donation process successfully");
	}
	
	//get donor
	@GetMapping("/{id}")
	public ResponseEntity<?> getReceipientDetails(@PathVariable Long id) {
		return ResponseEntity.ok(receipientService.getReceipientDetails(id));
	}

	//delete reciepient
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteReceipient(@PathVariable Long id) {
		String  message =  receipientService.deleteReceipientById(id);
		return ResponseEntity.ok(message);
	}

	// update methods...
	@PutMapping("/{id}")
	public ResponseEntity<ReceipientDTO> updateReceipient(
			@PathVariable Long id,
			@RequestBody ReceipientDTO updatedReceipientDTO) {

		ReceipientDTO updatedReceipient = receipientService.updateReceipient(id, updatedReceipientDTO);

		if (updatedReceipient != null) {
			return ResponseEntity.ok(updatedReceipient);
		} else {
			// Handle the case where the recipient with the given ID is not found
			return ResponseEntity.notFound().build();
		}
	}
}

