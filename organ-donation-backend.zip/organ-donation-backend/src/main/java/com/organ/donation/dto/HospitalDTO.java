package com.organ.donation.dto;

public class HospitalDTO {
	private Long id;
	private String address;
	private long hospitalContactNo;
	private String incharge;
	private long inchargeContactNo;
	private String hospitalName;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getHospitalContactNo() {
		return hospitalContactNo;
	}
	public void setHospitalContactNo(long hospitalContactNo) {
		this.hospitalContactNo = hospitalContactNo;
	}
	public String getIncharge() {
		return incharge;
	}
	public void setIncharge(String incharge) {
		this.incharge = incharge;
	}
	public long getInchargeContactNo() {
		return inchargeContactNo;
	}
	public void setInchargeContactNo(long inchargeContactNo) {
		this.inchargeContactNo = inchargeContactNo;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	
	
}
