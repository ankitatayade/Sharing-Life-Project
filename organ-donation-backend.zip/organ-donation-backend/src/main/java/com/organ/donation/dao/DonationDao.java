package com.organ.donation.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.organ.donation.entities.Donation;

public interface DonationDao extends JpaRepository<Donation, Integer> {

}
