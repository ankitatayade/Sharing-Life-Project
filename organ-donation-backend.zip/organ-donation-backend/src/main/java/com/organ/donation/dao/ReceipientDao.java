package com.organ.donation.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.organ.donation.entities.Receipients;



public interface ReceipientDao extends JpaRepository<Receipients, Long> {
	List<Receipients> findAll();
	
	Optional<Receipients> findByEmailAndPassword(String email,String pwd);
}
