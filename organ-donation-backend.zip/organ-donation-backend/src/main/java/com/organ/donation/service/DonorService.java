package com.organ.donation.service;

import java.util.List;

import com.organ.donation.dto.DonorDTO;
import com.organ.donation.dto.ReceipientDTO;
import com.organ.donation.dto.SignInRequest;
import com.organ.donation.entities.Admin;
import com.organ.donation.entities.Donors;

public interface DonorService {

	
	//get list of donors
	List<DonorDTO> getAllDonors();
	
	List<DonorDTO> getOrganwiseDonors(String organ);

	DonorDTO addNewDonor(DonorDTO donorDto);

	String deleteDonorById(Long id);
	
	DonorDTO getDonorDetails(Long id);

	DonorDTO updateDonor(Long id,DonorDTO updatedDonorDTO);
	
	Donors validate(SignInRequest request);

}
