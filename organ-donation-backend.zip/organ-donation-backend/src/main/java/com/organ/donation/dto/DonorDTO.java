package com.organ.donation.dto;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.organ.donation.entities.Hospital;


public class DonorDTO {
	private Long id;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateOfBirth;
	@NotBlank
	private String gender;
	@NotBlank
	private String location;
	//@NotBlank
	private Long mobileNo;
	@NotBlank
	private String name;
	@NotBlank
	private String organToBeDonated;
	@JsonProperty(access = Access.WRITE_ONLY)
	private String adharCardNumber;

	@JsonProperty(access = Access.WRITE_ONLY)
	private String password;
	@JsonProperty(access = Access.WRITE_ONLY)
	@Email
	@NotNull
	private String email;
	
	private String registerAs; //donor / guardian
	private String sugar;
	private String cholestrol;
	private String organtest;
	
	private Long hospitalId;
	private boolean isavailable;
	
	private Hospital hospital;
	
	public boolean isIsavailable() {
		return isavailable;
	}

	public void setIsavailable(boolean isavailable) {
		this.isavailable = isavailable;
	}

	public Hospital getHospital() {
		return hospital;
	}

	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}

	public Long getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(Long hospitalId) {
		this.hospitalId = hospitalId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOrganToBeDonated() {
		return organToBeDonated;
	}

	public void setOrganToBeDonated(String organToBeDonated) {
		this.organToBeDonated = organToBeDonated;
	}

	public String getAdharCardNumber() {
		return adharCardNumber;
	}

	public void setAdharCardNumber(String adharCardNumber) {
		this.adharCardNumber = adharCardNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRegisterAs() {
		return registerAs;
	}

	public void setRegisterAs(String registerAs) {
		this.registerAs = registerAs;
	}

	public String getSugar() {
		return sugar;
	}

	public void setSugar(String sugar) {
		this.sugar = sugar;
	}

	public String getCholestrol() {
		return cholestrol;
	}

	public void setCholestrol(String cholestrol) {
		this.cholestrol = cholestrol;
	}

	public String getOrgantest() {
		return organtest;
	}

	public void setOrgantest(String organtest) {
		this.organtest = organtest;
	}

	@Override
	public String toString() {
		return "DonorDTO [Id=" + id + ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + ", location=" + location
				+ ", mobileNo=" + mobileNo + ", name=" + name + ", organToBeDonated=" + organToBeDonated
				+ ", adharCardNumber=" + adharCardNumber +", password=" + password + ", email="
				+ email + ", registerAs=" + registerAs + ", sugar=" + sugar + ", cholestrol=" + cholestrol
				+ ", organtest=" + organtest + "]";
	}

	
	
}
