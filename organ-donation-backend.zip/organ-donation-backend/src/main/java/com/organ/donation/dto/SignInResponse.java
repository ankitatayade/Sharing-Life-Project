package com.organ.donation.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class SignInResponse {
private Long id; 
private String email;
}
