package com.organ.donation.service;

import java.util.List;

import com.organ.donation.dto.DonationDTO;
import com.organ.donation.dto.ReceipientDTO;
import com.organ.donation.dto.SignInRequest;
import com.organ.donation.entities.Receipients;



public interface ReceipientService {
	//get list of receipients
	List<ReceipientDTO> getAllReceipients();

	ReceipientDTO addNewReceipient(ReceipientDTO receipientDto);

	String deleteReceipientById(Long id);
	
	ReceipientDTO getReceipientDetails(Long id);

	ReceipientDTO updateReceipient(Long id, ReceipientDTO updatedReceipientDTO);

	Receipients validate(SignInRequest request);
	
	void donationProcess(DonationDTO dto);
}
