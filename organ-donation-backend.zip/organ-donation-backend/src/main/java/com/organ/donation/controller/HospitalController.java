package com.organ.donation.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.organ.donation.dto.HospitalDTO;
import com.organ.donation.dto.SignInRequest;
import com.organ.donation.entities.Admin;
import com.organ.donation.entities.Hospital;
import com.organ.donation.service.AdminService;
import com.organ.donation.service.HospitalServiceImpl;

@RestController
@CrossOrigin
@RequestMapping("/api/hospitals")
public class HospitalController {

	@Autowired
	private HospitalServiceImpl hospitalService;
	@Autowired private AdminService adminService;

	@GetMapping
	public ResponseEntity<List<Hospital>> getAllHospitals() {
		List<Hospital> hospitals = hospitalService.getAllHospitalEntries();
		return ResponseEntity.ok(hospitals);
	}

	//add new receiver details
	@PostMapping
	public ResponseEntity<?> addHospital(@RequestBody @Valid HospitalDTO hospital){
		System.out.println("in add new hospital "+hospital);
		return ResponseEntity
				.status(HttpStatus.CREATED)
				.body(hospitalService.saveHospital(hospital));
	}

	//validate login
	@PostMapping("/validate")
	public ResponseEntity<?> validateReciepients(@RequestBody @Valid SignInRequest request){
		System.out.println("in validate admin method "+request);
		Admin data = adminService.validate(request);
		if(data == null) {
			return ResponseEntity.status(404).body("Invalid username or password");
		}
		return ResponseEntity.ok(data);
	}

	@PostMapping("/registerAdmin")
	public ResponseEntity<?> registerAdmin(@RequestBody @Valid Admin request){
		System.out.println("in validate admin method "+request);
		adminService.registerAdmin(request);

		return ResponseEntity.ok("Admin user created successfully");
	}

	@GetMapping("/donations")
	public ResponseEntity<?> allDonations(){
		return ResponseEntity.ok(adminService.allDonations());
	}

}
