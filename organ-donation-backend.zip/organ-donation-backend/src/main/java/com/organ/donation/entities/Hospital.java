package com.organ.donation.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "hospital")
@NoArgsConstructor
@AllArgsConstructor
public class Hospital extends BaseEntity {
	@Column
	private String address;
	@Column
	private long hospitalContactNo;
	@Column
	private String incharge;
	@Column
	private long inchargeContactNo;
	@Column(length = 20)
	private String hospitalName;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getHospitalContactNo() {
		return hospitalContactNo;
	}

	public void setHospitalContactNo(long hospitalContactNo) {
		this.hospitalContactNo = hospitalContactNo;
	}

	public String getIncharge() {
		return incharge;
	}

	public void setIncharge(String incharge) {
		this.incharge = incharge;
	}

	public long getInchargeContactNo() {
		return inchargeContactNo;
	}

	public void setInchargeContactNo(long inchargeContactNo) {
		this.inchargeContactNo = inchargeContactNo;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
}
