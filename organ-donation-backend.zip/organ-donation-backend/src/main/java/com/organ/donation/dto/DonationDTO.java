package com.organ.donation.dto;

import java.time.LocalDate;

public class DonationDTO {
	private LocalDate operationdate;
	private int amount;
	private String cardno;
	private Long donorid;
	private Long recid;
	public LocalDate getOperationdate() {
		return operationdate;
	}
	public void setOperationdate(LocalDate operationdate) {
		this.operationdate = operationdate;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getCardno() {
		return cardno;
	}
	public void setCardno(String cardno) {
		this.cardno = cardno;
	}
	public Long getDonorid() {
		return donorid;
	}
	public void setDonorid(Long donorid) {
		this.donorid = donorid;
	}
	public Long getRecid() {
		return recid;
	}
	public void setRecid(Long recid) {
		this.recid = recid;
	}

	
}
