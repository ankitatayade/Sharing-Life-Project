package com.organ.donation.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
public class SignInRequest {

	@NotBlank(message = "Email Id field cannot be blank")
	@Email(message = "Invalid email format")
	private String email;
	@NotBlank
	@Length(min=5, max=12 ,message = "Invalid password length")
	private String password;
	
	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

}
