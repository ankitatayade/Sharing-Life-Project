package com.organ.donation.entities;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Donation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@ManyToOne
	@JoinColumn(name = "donor_id")
	private Donors donor;
	@ManyToOne
	@JoinColumn(name = "rec_id")
	private Receipients receipient;
	
	private LocalDate operationdate;
	private int amount;
	private String cardno;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Donors getDonor() {
		return donor;
	}
	public void setDonor(Donors donor) {
		this.donor = donor;
	}
	public Receipients getReceipient() {
		return receipient;
	}
	public void setReceipient(Receipients receipient) {
		this.receipient = receipient;
	}
	public LocalDate getOperationdate() {
		return operationdate;
	}
	public void setOperationdate(LocalDate operationdate) {
		this.operationdate = operationdate;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getCardno() {
		return cardno;
	}
	public void setCardno(String cardno) {
		this.cardno = cardno;
	}
	
	
}
