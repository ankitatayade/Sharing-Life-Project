package com.organ.donation.service;

import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.organ.donation.dao.HospitalDao;
import com.organ.donation.dto.HospitalDTO;
import com.organ.donation.entities.Hospital;

@Service
@Transactional
public class HospitalServiceImpl {
	
	@Autowired
    private HospitalDao hospitalDao;
	@Autowired ModelMapper mapper;
	
    public List<Hospital> getAllHospitalEntries() {
        return hospitalDao.findAll();
    }
    
    public Hospital saveHospital(HospitalDTO dto) {
    	Hospital hospital = mapper.map(dto, Hospital.class);
    	return hospitalDao.save(hospital);
    }
   
}
