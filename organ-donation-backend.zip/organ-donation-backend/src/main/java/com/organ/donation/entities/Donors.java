package com.organ.donation.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "donors")
@NoArgsConstructor
@AllArgsConstructor
public class Donors extends BaseEntity {
	@Column (length = 20)
	private String email;
	@Column(length = 20)
	private String password;
	@Column
	private String adharCardNumber;
	@Column
	private LocalDate dateOfBirth;
	@Column
	private String gender;
	@Column
	private long mobileNo;
	@Column(length = 20)
	private String name;
	
    @Column(length = 20)
    private String location;

	@Column(length = 20)
	private String organToBeDonated;
	@Column
	private String sugar;
	@Column
	private String cholestrol;
	@Column
	private String organtest;
	
	@Column
	private String registerAs;
	
	@ManyToOne
	@JoinColumn(name="hospital_id")
	private Hospital hospital;
	
	private boolean isavailable;
	
	
	
	public boolean isIsavailable() {
		return isavailable;
	}

	public void setIsavailable(boolean isavailable) {
		this.isavailable = isavailable;
	}

	public Hospital getHospital() {
		return hospital;
	}

	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAdharCardNumber() {
		return adharCardNumber;
	}

	public void setAdharCardNumber(String adharCardNumber) {
		this.adharCardNumber = adharCardNumber;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getOrganToBeDonated() {
		return organToBeDonated;
	}

	public void setOrganToBeDonated(String organToBeDonated) {
		this.organToBeDonated = organToBeDonated;
	}

	public String getSugar() {
		return sugar;
	}

	public void setSugar(String sugar) {
		this.sugar = sugar;
	}

	public String getCholestrol() {
		return cholestrol;
	}

	public void setCholestrol(String cholestrol) {
		this.cholestrol = cholestrol;
	}

	public String getOrgantest() {
		return organtest;
	}

	public void setOrgantest(String organtest) {
		this.organtest = organtest;
	}

	public String getRegisterAs() {
		return registerAs;
	}

	public void setRegisterAs(String registerAs) {
		this.registerAs = registerAs;
	}

	@Override
	public String toString() {
		return "Donors [email=" + email + ", password=" + password + ", adharCardNumber=" + adharCardNumber
				+ ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + ", mobileNo=" + mobileNo + ", name=" + name
				+ ", location=" + location +", organToBeDonated=" + organToBeDonated + ", sugar="
				+ sugar + ", cholestrol=" + cholestrol + ", organtest=" + organtest + ", registerAs=" + registerAs
				+ "]";
	}
	
	

}
