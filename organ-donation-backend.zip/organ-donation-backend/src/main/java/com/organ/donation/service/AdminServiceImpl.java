package com.organ.donation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.organ.donation.dao.AdminDao;
import com.organ.donation.dao.DonationDao;
import com.organ.donation.dto.SignInRequest;
import com.organ.donation.entities.Admin;
import com.organ.donation.entities.Donation;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired private AdminDao dao;
	@Autowired private DonationDao donationDao;
	
	@Override
	public void registerAdmin(Admin admin) {
		// TODO Auto-generated method stub
		if(dao.count()==0) {
			dao.save(admin);
		}
	}

	@Override
	public Admin validate(SignInRequest request) {
		// TODO Auto-generated method stub
		Optional<Admin> admin = dao.findByUseridAndPwd(request.getEmail(), request.getPassword());
		return admin.orElse(null);
	}

	@Override
	public List<Donation> allDonations() {
		// TODO Auto-generated method stub
		return donationDao.findAll(Sort.by(Direction.DESC, "id"));
	}
	
	
}
