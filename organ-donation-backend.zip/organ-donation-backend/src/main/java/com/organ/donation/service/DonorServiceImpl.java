package com.organ.donation.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.organ.donation.custom_exceptions.ResourceNotFoundException;
import com.organ.donation.dao.DonorDao;
import com.organ.donation.dto.DonorDTO;
import com.organ.donation.dto.SignInRequest;
import com.organ.donation.entities.Donors;
import com.organ.donation.entities.Hospital;

@Service
@Transactional
public class DonorServiceImpl implements DonorService {


	@Autowired
	private DonorDao donorDao;
	@Autowired
	private ModelMapper mapper;
	
	

	@Override
	public List<DonorDTO> getOrganwiseDonors(String organ) {
		// TODO Auto-generated method stub
		return donorDao.findByOrganToBeDonatedAndIsavailable(organ,true)
				.stream()
				.map(donor->mapper.map(donor,DonorDTO.class)).toList();
	}


	@Override
	public List<DonorDTO> getAllDonors() {
		return donorDao.findAll()
				.stream()
				.map(donor->mapper.map(donor,DonorDTO.class))
				.collect(Collectors.toList());		
	}


	@Override
	public DonorDTO getDonorDetails(Long id) {
		// TODO Auto-generated method stub
		return donorDao.findById(id).stream().map(donor -> mapper.map(donor, DonorDTO.class)).findFirst().orElse(null);
	}


	@Override
	public DonorDTO addNewDonor(DonorDTO donorDto) {

		Donors donorEntity = mapper.map(donorDto,Donors.class);
		Hospital hospital = new Hospital();
		hospital.setId(donorDto.getHospitalId());
		donorEntity.setHospital(hospital);
		donorEntity.setIsavailable(true);
		Donors persistentDonor = donorDao.save(donorEntity);
		
		return mapper.map(persistentDonor, DonorDTO.class);

	}


	@Override
	public String deleteDonorById(Long id) {
		Optional<Donors> optionalDonor = donorDao.findById(id);

		if (optionalDonor.isPresent()) {
			Donors donor = optionalDonor.get();

			// Delete the recipient
			donorDao.delete(donor);
			return "deleted successfully";
		} else {
			// Handle the case where the recipient with the given ID is not found
			throw new ResourceNotFoundException("Donor not found with ID: " + id);
		}
	}



	@Override
	public DonorDTO updateDonor(Long id, DonorDTO updatedDonorDTO) {
		Optional<Donors> optionalDonor = donorDao.findById(id);

		if (optionalDonor.isPresent()) {
			Donors existingDonor = mapper.map(updatedDonorDTO, Donors.class);
			Donors updatedDonor = donorDao.save(existingDonor);

			// Map and return the updated DTO
			return mapper.map(updatedDonor, DonorDTO.class);
		} else {
			// Handle the case where the recipient with the given ID is not found
			return null;
		}
	}
	@Override
	public Donors validate(SignInRequest request) {
		// TODO Auto-generated method stub
		return donorDao.findByEmailAndPassword(request.getEmail(), request.getPassword()).orElse(null);
	}
	
	
}


