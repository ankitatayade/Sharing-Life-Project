package com.organ.donation.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.organ.donation.dto.DonorDTO;
import com.organ.donation.dto.SignInRequest;
import com.organ.donation.entities.Donors;
import com.organ.donation.service.DonorService;


@RestController
@RequestMapping("/api/donors")
@CrossOrigin
@Validated
public class DonorController {
	@Autowired
	private DonorService donorService;

	//get donor details
	//http://host:port/donors
	@GetMapping
	public ResponseEntity<?> getAllReceipients(){
		System.out.println("in get all donor method");
		return ResponseEntity.ok(donorService.getAllDonors());
	}
	
	@GetMapping("search")
	public ResponseEntity<?> searchReceipients(String organ){
		System.out.println("in get all organ wise donor method");
		return ResponseEntity.ok(donorService.getOrganwiseDonors(organ));
	}
	
	//validate login
	@PostMapping("/validate")
	public ResponseEntity<?> validateDonor(@RequestBody @Valid SignInRequest request){
		System.out.println("in validate donor method "+request);
		Donors donor = donorService.validate(request);
		if(donor == null) {
			return ResponseEntity.status(404).body("Invalid username or password");
		}
		return ResponseEntity.ok(donor);
	}

	//add new receiver details
	@PostMapping
	public ResponseEntity<?> addNewDonor(@RequestBody @Valid DonorDTO donorDto){
		System.out.println("in add new receiver"+donorDto);
		return ResponseEntity
				.status(HttpStatus.CREATED)
				.body(donorService.addNewDonor(donorDto));
	}

	//delete reciepient
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteDonor(@PathVariable Long id) {
		String  message =  donorService.deleteDonorById(id);
		return ResponseEntity.ok(message);
	}
	
	//get donor
	@GetMapping("/{id}")
	public ResponseEntity<?> getDonorDetails(@PathVariable Long id) {
		return ResponseEntity.ok(donorService.getDonorDetails(id));
	}

	// update methods...
	//
	@PutMapping("/{id}")
	public ResponseEntity<DonorDTO> updateDonor(
			@PathVariable Long id,
			@RequestBody DonorDTO updatedDonorDTO) {

		DonorDTO updatedDonor = donorService.updateDonor(id, updatedDonorDTO);

		if (updatedDonor != null) {
			return ResponseEntity.ok(updatedDonor);
		} else {
			// Handle the case where the recipient with the given ID is not found
			return ResponseEntity.notFound().build();
		}
	}
}

