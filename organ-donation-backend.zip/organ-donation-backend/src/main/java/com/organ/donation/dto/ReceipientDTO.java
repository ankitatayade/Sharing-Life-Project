package com.organ.donation.dto;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ReceipientDTO {
@JsonProperty(access = Access.READ_ONLY)
private Long id;
@DateTimeFormat(pattern = "yyyy-MM-dd")
private LocalDate dateOfBirth;
@NotBlank
private String gender;
@NotBlank
private String location;
//@NotBlank
private Long mobileNo;
@NotBlank
private String name;
@NotBlank
private String organToBeTransplanted;
@JsonProperty(access = Access.WRITE_ONLY)
private String adharCardNumber;
@JsonProperty(access = Access.WRITE_ONLY)
private String password;
@JsonProperty(access = Access.WRITE_ONLY)
@Email
@NotNull
private String email;

private String sugar;
private String cholestrol;
private String organtest;

public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public LocalDate getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(LocalDate dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public Long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(Long mobileNo) {
	this.mobileNo = mobileNo;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getOrganToBeTransplanted() {
	return organToBeTransplanted;
}
public void setOrganToBeTransplanted(String organToBeTransplanted) {
	this.organToBeTransplanted = organToBeTransplanted;
}
public String getAdharCardNumber() {
	return adharCardNumber;
}
public void setAdharCardNumber(String adharCardNumber) {
	this.adharCardNumber = adharCardNumber;
}

public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getSugar() {
	return sugar;
}
public String getCholestrol() {
	return cholestrol;
}
public String getOrgantest() {
	return organtest;
}
public void setSugar(String sugar) {
	this.sugar = sugar;
}
public void setCholestrol(String cholestrol) {
	this.cholestrol = cholestrol;
}
public void setOrgantest(String organtest) {
	this.organtest = organtest;
}


}
