package com.organ.donation.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.organ.donation.entities.Donors;

public interface DonorDao extends JpaRepository<Donors, Long> {

	Optional<Donors> findByEmailAndPassword(String email,String pwd);
	List<Donors> findByOrganToBeDonatedAndIsavailable(String organ,boolean flag);

}
