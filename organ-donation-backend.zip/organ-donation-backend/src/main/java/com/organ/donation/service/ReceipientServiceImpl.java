package com.organ.donation.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.organ.donation.custom_exceptions.ResourceNotFoundException;
import com.organ.donation.dao.DonationDao;
import com.organ.donation.dao.DonorDao;
import com.organ.donation.dao.ReceipientDao;
import com.organ.donation.dto.DonationDTO;
import com.organ.donation.dto.ReceipientDTO;
import com.organ.donation.dto.SignInRequest;
import com.organ.donation.entities.Donation;
import com.organ.donation.entities.Donors;
import com.organ.donation.entities.Receipients;


@Service
@Transactional
public class ReceipientServiceImpl implements ReceipientService {

	@Autowired
	private ReceipientDao receipientDao;
	@Autowired
	private ModelMapper mapper;
	
	@Autowired DonationDao donationDao;
	
	@Autowired DonorDao donorService;
	
	
	@Override
	public ReceipientDTO getReceipientDetails(Long id) {
		// TODO Auto-generated method stub
		return receipientDao.findById(id).stream().map(rec -> mapper.map(rec,ReceipientDTO.class)).findFirst().orElse(null);
	}

	@Override
	public Receipients validate(SignInRequest request) {
		// TODO Auto-generated method stub
		return receipientDao.findByEmailAndPassword(request.getEmail(), request.getPassword()).orElse(null);
	}
	
	

	@Override
	public void donationProcess(DonationDTO dto) {
		// TODO Auto-generated method stub
		Donors donor = donorService.findById(dto.getDonorid()).get();
		donor.setIsavailable(false);
		donorService.save(donor);
		
		Receipients recp = receipientDao.findById(dto.getRecid()).get();
		
		Donation donation = mapper.map(dto, Donation.class);
		donation.setDonor(donor);
		donation.setReceipient(recp);
		donation.setOperationdate(LocalDate.now());
		
		donationDao.save(donation);
		
	}

	@Override
	public List<ReceipientDTO> getAllReceipients() {

		return receipientDao.findAll()
				.stream()
				.map(receipient->mapper.map(receipient,ReceipientDTO.class))
				.collect(Collectors.toList());		
	}

	@Override
	public ReceipientDTO addNewReceipient(ReceipientDTO receipientDto) {
		Receipients receipientEntity = mapper.map(receipientDto,Receipients.class);
		Receipients persistentReceipient = receipientDao.save(receipientEntity);
		return mapper.map(persistentReceipient, ReceipientDTO.class);

	}



	public String deleteReceipientById(Long id) {
		Optional<Receipients> optionalReceipient = receipientDao.findById(id);

		if (optionalReceipient.isPresent()) {
			Receipients receipient = optionalReceipient.get();
			// Delete the recipient
			receipientDao.delete(receipient);
			return "deleted successfully";
		} else {
			// Handle the case where the recipient with the given ID is not found
			throw new ResourceNotFoundException("Receipient not found with ID: " + id);
		}
	}




	@Override
	public ReceipientDTO updateReceipient(Long id, ReceipientDTO updatedReceipientDTO) {
		Optional<Receipients> optionalReceipient = receipientDao.findById(id);

		if (optionalReceipient.isPresent()) {
			Receipients existingReceipient = optionalReceipient.get();

			// Update the fields with the new values
			existingReceipient.setName(updatedReceipientDTO.getName());
			existingReceipient.setDateOfBirth(updatedReceipientDTO.getDateOfBirth());
			existingReceipient.setGender(updatedReceipientDTO.getGender());
			// ... (update other fields)

			// Save the updated recipient
			Receipients updatedReceipient = receipientDao.save(existingReceipient);

			// Map and return the updated DTO
			return mapper.map(updatedReceipient, ReceipientDTO.class);
		} else {
			// Handle the case where the recipient with the given ID is not found
			return null;
		}
	}
}



