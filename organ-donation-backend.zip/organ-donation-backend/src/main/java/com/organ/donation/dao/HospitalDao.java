package com.organ.donation.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.organ.donation.entities.Hospital;

public interface HospitalDao extends JpaRepository<Hospital, Long>{

}
