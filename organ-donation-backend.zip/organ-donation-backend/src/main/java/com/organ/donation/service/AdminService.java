package com.organ.donation.service;

import java.util.List;

import com.organ.donation.dto.SignInRequest;
import com.organ.donation.entities.Admin;
import com.organ.donation.entities.Donation;

public interface AdminService {

	void registerAdmin(Admin admin);
	Admin validate(SignInRequest request);
	List<Donation> allDonations();
}
