import { BrowserRouter, Route, Routes } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/DonorRegister';
import ReceipientRegister from './pages/RecepientRegister';
import Dashboard from './pages/Dashboard';
import Donors from './pages/Donors';
import Receipients from './pages/Receipients';
import AddHospital from './pages/AddHospital';
import Hospitals from './pages/Hospitals';
import DonorHome from './pages/DonorHome';
import ReceipeintHome from './pages/ReceipientHome';
import OrganDonors from './pages/OrganDonors';
import BuyNow from './pages/BuyNow';
import Donations from './pages/Donations';

function App() {
  return (
    <BrowserRouter>      
      <Routes>
        <Route element={<LoginPage />} path="/" exact />    
        <Route element={<RegisterPage />} path="/dregister" />    
        <Route element={<ReceipientRegister />} path="/register" />    
        <Route element={<Dashboard />} path="/dashboard" />    
        <Route element={<Donors />} path="/donors" />    
        <Route element={<Receipients />} path="/receipients" />    
        <Route element={<Hospitals />} path="/hospitals" />    
        <Route element={<AddHospital />} path="/addhospital" />    
        <Route element={<DonorHome />} path="/uhome" />    
        <Route element={<ReceipeintHome />} path="/rhome" />    
        <Route element={<OrganDonors />} path="/search" />    
        <Route element={<BuyNow />} path="/buynow/:id" />    
        <Route element={<Donations />} path="/donations" />    
      </Routes>
    </BrowserRouter>
  );
}

export default App;
