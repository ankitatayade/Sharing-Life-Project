import { useDispatch } from "react-redux"
import { Link, useLocation, useNavigate } from "react-router-dom"
var classNames = require('classnames');

function SideBar(){    
    const navigate=useNavigate()
    const dispatch=useDispatch()
    const location=useLocation()
    const role=sessionStorage.getItem("role")
    const navclass="list-group-item list-group-item-action p-2 text-left";
    console.log(location.pathname)
    const logout=()=>{
        dispatch({type:'LogOut'})
        sessionStorage.clear();
        navigate("/");
    }
    return(
<div className="list-group list-group-flush">
    {role==="Admin" ? (<>
        <Link to="/dashboard" className={classNames(navclass,{"active":location.pathname=="/dashboard"})}>Dashboard</Link>                                                                                                
        <Link to="/donors" className={classNames(navclass,{"active":location.pathname=="/donors"})}>Donors</Link>
        <Link to="/receipients" className={classNames(navclass,{"active":location.pathname=="/receipients"})}>Receipients</Link>
        <Link to="/hospitals" className={classNames(navclass,{"active":location.pathname=="/hospitals"})}>Hospitals</Link>
        <Link to="/donations" className={classNames(navclass,{"active":location.pathname=="/donations"})}>Donations</Link>
        </>): role==="Receipients" ? (
            <>
        <Link to="/rhome" className={classNames(navclass,{"active":location.pathname=="/shome"})}>Profile</Link>
        <Link to="/search" className={classNames(navclass,{"active":location.pathname=="/students"})}>Search Donors</Link>
    </>) :(<>        
        </>
    )}
    <button onClick={()=>logout()} className={classNames(navclass,"btn-link")}>Logout</button>
</div>
    )
}

export default SideBar;