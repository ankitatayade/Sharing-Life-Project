import axios from "axios";
import { useEffect, useState } from "react";
import Header from "../components/Header";
import { useDispatch } from "react-redux"
import { useNavigate } from "react-router-dom"

function DonorHome(){
    const cid=sessionStorage.getItem("id")
    const [donorInfo,setdonorInfo]=useState()
    const navigate=useNavigate()
    const dispatch=useDispatch()
    useEffect(()=>{
        axios.get("http://localhost:8080/api/donors/"+cid)
        .then(resp=>{
            setdonorInfo(resp.data)             
        })
        .catch(err=>{
            console.log(err)
        })
    },[])

    const logout=()=>{
        dispatch({type:'LogOut'})
        sessionStorage.clear();
        navigate("/");
    }

    return (
        <>
        <Header/>   
        <div className="container-fluid">
        <button onClick={()=>logout()} className="btn btn-primary float-right">Logout</button>
            <div className="row">
                <div className="col-sm-6 mx-auto p-3">
                    <div className="card shadow">
                        <div className="card-header">
                            <h5>Donor Profile</h5>
                        </div>
                        <div className="card-body">
                        <table className="table table-borderless">
                            <tbody>
                                <tr>
                                    <th>Donor Name</th>
                                    <th>{donorInfo?.name}</th>
                                </tr>
                                <tr>
                                    <th>Address</th>
                                    <th>{donorInfo?.location}</th>
                                </tr>
                                <tr>
                                    <th>Date of Birth</th>
                                    <th>{donorInfo?.dateOfBirth}</th>
                                </tr>
                                <tr>
                                    <th>Register As</th>
                                    <th>{donorInfo?.registerAs}</th>
                                </tr>
                                <tr>
                                    <th>Mobile</th>
                                    <th>{donorInfo?.mobileNo}</th>
                                </tr>
                                <tr>
                                    <th>Organ Donated</th>
                                    <th>{donorInfo?.organToBeDonated}</th>
                                </tr>
                                <tr>
                                    <th>Hospital Name</th>
                                    <th>{donorInfo?.hospital.hospitalName}</th>
                                </tr>                                
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </>
    )}

export default DonorHome;