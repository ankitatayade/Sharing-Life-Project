import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import SideBar from "../components/SideBar";

function Donors(){
    const [donors,setDonors]=useState([])
    const navigate=useNavigate()
    const loadData=()=>{
        axios.get("http://localhost:8080/api/donors")
        .then(resp=>{
            setDonors(resp.data)
            console.log(donors)
        })
    }
    
    
    useEffect(()=>{
        loadData();
    },[])
    return(
        <>
        <Header/>
        <div className="container-fluid">
            <div className="row">
                <div className="col-sm-2 bg-transparent p-0 border-right border-primary" style={{height:"calc(100vh - 80px)"}}>
                    <SideBar />
                </div>
                <div className="col-sm-10">
                    <h4 className="text-left p-2 border-bottom border-success">All Donors</h4>
                    <table className="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Donor Name</th>
                        <th>Address</th>
                        <th>Gender</th>
                        <th>Mobile No</th>
                        <th>Date of Birth</th>
                        <th>Organ to donate</th>
                        <th>Hospital</th>
                        {/*<th>Action</th> */ }
                    </tr>
                </thead>
                <tbody>
                {donors.map(x=>(
                    <tr key={x.id}>
                        <td>{x.id}</td>
                        <td>{x.name}</td>
                        <td>{x.location}</td>
                        <td>{x.gender}</td>
                        <td>{x.mobileNo}</td>
                        <td>{x.dateOfBirth}</td>
                        <td>{x.organToBeDonated}</td>
                        <td>{x.hospital.hospitalName}</td>
                        
                            {/*<button onClick={e=>handleDelete(x.id)} className="btn btn-danger btn-sm">Delete</button> */}
                            {/* <button onClick={e=>handleEdit(x.id)} className="btn btn-success ml-2 btn-sm">Edit</button> */}
                        
                    </tr>
                ))}
                </tbody>
            </table>
                </div>
            </div>
        </div>
        </>
    )
}

export default Donors;