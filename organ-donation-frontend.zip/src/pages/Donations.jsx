import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import SideBar from "../components/SideBar";

function Donations(){
    const [Donations,setDonations]=useState([])
    const navigate=useNavigate()
    const loadData=()=>{
        axios.get("http://localhost:8080/api/hospitals/donations")
        .then(resp=>{
            setDonations(resp.data)
            console.log(Donations)
        })
    }
    
    
    useEffect(()=>{
        loadData();
    },[])
    return(
        <>
        <Header/>
        <div className="container-fluid">
            <div className="row">
                <div className="col-sm-2 bg-transparent p-0 border-right border-primary" style={{height:"calc(100vh - 80px)"}}>
                    <SideBar />
                </div>
                <div className="col-sm-10">
                    <h4 className="text-left p-2 border-bottom border-success">All Donations</h4>
                    <table className="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Donor Name</th>
                        <th>Receipient Name</th>
                        <th>Gender</th>
                        <th>Mobile No</th>
                        <th>Operation Date</th>
                        <th>Organ donate</th>
                        <th>Hospital Name</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                {Donations.map(x=>(
                    <tr key={x.id}>
                        <td>{x.id}</td>
                        <td>{x.donor.name}</td>
                        <td>{x.receipient.name}</td>
                        <td>{x.receipient.gender}</td>
                        <td>{x.receipient.mobileNo}</td>
                        <td>{x.operationdate}</td>
                        <td>{x.donor.organToBeDonated}</td>
                        <td>{x.donor.hospital.hospitalName}</td>
                        <td>Rs.{x.amount}</td>
                    </tr>
                ))}
                </tbody>
            </table>
                </div>
            </div>
        </div>
        </>
    )
}

export default Donations;