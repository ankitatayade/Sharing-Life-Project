import axios from "axios"
import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import Header from "../components/Header";
import SideBar from "../components/SideBar";

function AddHospital(){
    const [user,setUser]=useState(null)
    const navigate = useNavigate()
 
    const handleInput=(e)=>{
        setUser({...user,[e.target.name]:e.target.value})
    }

    
    const handleSubmit=(e)=>{
        e.preventDefault()
            axios.post("http://localhost:8080/api/hospitals",user)
            .then(resp=>{
                console.log(resp)
                setUser(null)
                e.target.reset()
                alert("Hospital registered successfully")
                navigate("/hospitals")
            })
            .catch(error=>console.log("Error",error))                        
    }
    
    return(
        <>
        <Header/>
        <div className="container-fluid">
            <div className="row">
                <div className="col-sm-2 bg-transparent p-0 border-right border-primary" style={{height:"calc(100vh - 80px)"}}>
                    <SideBar />
                </div>
                <div className="col-sm-9">
            <div className="card shadow mx-auto mt-3">
            <div className="card-body">
            <h4 className="text-center p-2">
                Add Hospital
            </h4>
            <form onSubmit={handleSubmit}>
                <div className="row">                    
                    <div className="col-sm-6 mx-auto">
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Hospital Name</label>
                            <div className="col-sm-8">
                                <input type="text" name="hospitalName" required value={user?.hospitalName} onChange={handleInput} className="form-control form-control-sm" />
                            </div>
                            
                        </div>
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Address</label>
                            <div className="col-sm-8">
                                <input type="text" name="address" required value={user?.address} onChange={handleInput} className="form-control form-control-sm" />
                            </div>                        
                        </div>
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Incharge</label>
                            <div className="col-sm-8">
                                <input type="text" name="incharge" required value={user?.incharge} onChange={handleInput} className="form-control form-control-sm" />
                            </div>                        
                        </div>
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Incharge ContactNo</label>
                            <div className="col-sm-8">
                                <input type="text" maxLength="10" required name="inchargeContactNo" value={user?.inchargeContactNo} onChange={handleInput} className="form-control form-control-sm" />
                            </div>
                            
                        </div>
                        
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Hospital ContactNo</label>
                            <div className="col-sm-8">
                                <input type="text" maxLength="10" required name="hospitalContactNo" value={user?.hospitalContactNo} onChange={handleInput} className="form-control form-control-sm" />
                            </div>
                            
                        </div>                                               
                        <button className="btn btn-primary btn-sm float-right">Submit</button>
                    </div>
                    </div>
                    </form>
                </div>
            </div>
            </div>
            </div>
            </div>
            </>
    )
}

export default AddHospital;