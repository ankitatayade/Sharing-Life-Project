import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import SideBar from "../components/SideBar";


function Receipients(){
    const [receipients,setreceipients]=useState([])
    const navigate=useNavigate()
    const loadData=()=>{
        axios.get("http://localhost:8080/api/receipients")
        .then(resp=>{
            setreceipients(resp.data)
            console.log(receipients)
        })
    }
    const handleDelete=id=>{
        let result=window.confirm('Are you sure to delete this record ?');
        if(result){
            axios.delete("http://localhost:8080/api/receipients/"+id)
            .then(resp=>{
                alert(resp.data.data)
                console.log(resp.data)
                loadData()
            })
            .catch(error=>{
                console.log(error)
            })
        }        
    }
    useEffect(()=>{
        loadData();
    },[])
    return(
        <>
        <Header/>
        <div className="container-fluid">
            <div className="row">
                <div className="col-sm-2 bg-transparent p-0 border-right border-primary" style={{height:"calc(100vh - 80px)"}}>
                    <SideBar />
                </div>
                <div className="col-sm-10">
                    <h4 className="text-left p-2 border-bottom border-success">All Receipients</h4>
                    <table className="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Receipient Name</th>
                        <th>Address</th>
                        <th>Gender</th>
                        <th>Mobile No</th>
                        <th>Date of Birth</th>
                        <th>Organ to donate</th>
                    </tr>
                </thead>
                <tbody>
                {receipients.map(x=>(
                    <tr key={x.id}>
                        <td>{x.id}</td>
                        <td>{x.name}</td>
                        <td>{x.location}</td>
                        <td>{x.gender}</td>
                        <td>{x.mobileNo}</td>
                        <td>{x.dateOfBirth}</td>
                        <td>{x.organToBeTransplanted}</td>
                        
                    </tr>
                ))}
                </tbody>
            </table>
                </div>
            </div>
        </div>
        </>
    )
}

export default Receipients;