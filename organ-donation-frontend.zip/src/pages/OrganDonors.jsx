import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import SideBar from "../components/SideBar";

function OrganDonors(){
    const [donors,setDonors]=useState([])
    const navigate=useNavigate()    
    const organ = sessionStorage.getItem("organ")
    const loadData=()=>{
       
            axios.get("http://localhost:8080/api/donors/search?organ="+organ)
            .then(resp=>{
                setDonors(resp.data)
                console.log(donors)
            })
        
    }
    
    
    useEffect(()=>{
        loadData();
    },[])
    return(
        <>
        <Header/>
        <div className="container-fluid">
            <div className="row">
                <div className="col-sm-2 bg-transparent p-0 border-right border-primary" style={{height:"calc(100vh - 80px)"}}>
                    <SideBar />
                </div>
                <div className="col-sm-10">
                    <h4 className="text-left p-2 border-bottom border-success">{organ} Donors</h4>
                    <table className="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Donor Name</th>
                        <th>Address</th>
                        <th>Gender</th>
                        <th>Mobile No</th>
                        <th>Date of Birth</th>
                        <th>Hospital</th>
                        <th>Sugar</th>
                        <th>Cholestrol</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                {donors.map(x=>(
                    <tr key={x.id}>
                        <td>{x.name}</td>
                        <td>{x.location}</td>
                        <td>{x.gender}</td>
                        <td>{x.mobileNo}</td>
                        <td>{x.dateOfBirth}</td>
                        <td>{x.hospital.hospitalName}</td>
                        <td>{x.sugar}</td>
                        <td>{x.cholestrol}</td>
                        <td>
                            <button onClick={e=>navigate("/buynow/"+x.id)} className="btn btn-success btn-sm">Buy Organ</button>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
                </div>
            </div>
        </div>
        </>
    )
}

export default OrganDonors;