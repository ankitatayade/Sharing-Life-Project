import axios from "axios"
import { useState } from "react"
import TopNavbar from "../components/TopNavbar"

function ReceipientRegister(){
    const [user,setUser]=useState(null)
 
    const handleInput=(e)=>{
        setUser({...user,[e.target.name]:e.target.value})
    }

    const handleSubmit=(e)=>{
        e.preventDefault()
            console.log(user)
            axios.post("http://localhost:8080/api/receipients",user)
            .then(resp=>{
                console.log(resp)
                setUser(null)                
                e.target.reset()
                alert("Receipeint registered successfully")
            })
            .catch(error=>console.log("Error",error))                        
    }
    
    return(
        <>
      <TopNavbar/>   
      <div className="container-fluid">
            <div className="row">                
                <div className="col-sm-11 mx-auto">
            <div className="card shadow mx-auto" style={{marginTop:"80px"}}>
            <div className="card-body">
            <h4 className="text-center p-2">
                Receipient Registration
            </h4>
            <form onSubmit={handleSubmit}>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Receipient Name</label>
                            <div className="col-sm-8">
                                <input type="text" required name="name" value={user?.name} onChange={handleInput} className="form-control form-control-sm" />
                            </div>                            
                        </div>
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Address</label>
                            <div className="col-sm-8">
                                <input type="text" required name="location" value={user?.location} onChange={handleInput} className="form-control form-control-sm" />
                            </div>                        
                        </div>
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Gender</label>
                            <div className="col-sm-8">
                                <select name="gender" required value={user?.gender} onChange={handleInput} className="form-control form-control-sm">
                                    <option value="">Select Gender</option>
                                    <option>Male</option>     
                                    <option>Female</option>     
                                </select> 
                            </div>                        
                        </div>
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Email Id</label>
                            <div className="col-sm-8">
                                <input type="email" required name="email" value={user?.email} onChange={handleInput} className="form-control form-control-sm" />
                            </div>
                            
                        </div>
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Password</label>
                            <div className="col-sm-8">
                                <input type="password" required name="password" value={user?.password} onChange={handleInput} className="form-control form-control-sm" />
                            </div>
                        </div> 
                            <div className="form-group form-row">
                                <label className="col-sm-4 form-control-label">Date of Birth</label>
                                <div className="col-sm-8">
                                    <input type="date" name="dateOfBirth" value={user?.dateOfBirth} onChange={handleInput} className="form-control form-control-sm" />
                                </div>
                                
                            </div>

                        </div>
                        <div className="col-sm-6">
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Phone</label>
                            <div className="col-sm-8">
                                <input type="text" maxLength="10" name="mobileNo" value={user?.mobileNo} onChange={handleInput} className="form-control form-control-sm" />
                            </div>
                            
                        </div>
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Aadhar No</label>
                            <div className="col-sm-8">
                                <input type="text" maxLength="12" name="adharCardNumber" value={user?.adharCardNumber} onChange={handleInput} className="form-control form-control-sm" />
                            </div>
                            
                        </div>
                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Organ to Transplant</label>
                            <div className="col-sm-8">
                                <input type="text" name="organToBeTransplanted" value={user?.organToBeTransplanted} onChange={handleInput} className="form-control form-control-sm" />
                            </div>                        
                        </div>

                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Sugar</label>
                            <div className="col-sm-8">
                                <input type="text" name="sugar" value={user?.sugar} onChange={handleInput} className="form-control form-control-sm" />
                            </div>                        
                        </div>

                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Cholestrol</label>
                            <div className="col-sm-8">
                                <input type="text" name="cholestrol" value={user?.cholestrol} onChange={handleInput} className="form-control form-control-sm" />
                            </div>                        
                        </div>

                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label">Organ test</label>
                            <div className="col-sm-8">
                                <input type="text" name="organtest" value={user?.organtest} onChange={handleInput} className="form-control form-control-sm" />
                            </div>                        
                        </div>
                        
                                               
                        <button className="btn btn-primary btn-sm float-right">Register Now</button>
                    </div>
                    </div>
                    </form>
                </div>
            </div>
            </div>
            </div>
            </div>
            </>
    )
}

export default ReceipientRegister;