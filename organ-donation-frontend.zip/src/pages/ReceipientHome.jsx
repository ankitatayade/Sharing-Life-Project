import axios from "axios";
import { useEffect, useState } from "react";
import Header from "../components/Header";
import SideBar from "../components/SideBar";

function ReceipeintHome(){
    const cid=sessionStorage.getItem("id")
    const [data,setdata]=useState()
    useEffect(()=>{
        axios.get("http://localhost:8080/api/receipients/"+cid)
        .then(resp=>{
            setdata(resp.data)             
        })
        .catch(err=>{
            console.log(err)
        })
    },[])
    return (
        <>
        <Header/>   
        <div className="container-fluid">
            <div className="row">
                <div className="col-sm-2 bg-transparent p-0 border-right border-primary" style={{height:"calc(100vh - 80px)"}}>
                    <SideBar />
                </div>
                <div className="col-sm-6 p-3">
                    <div className="card shadow">
                        <div className="card-header">
                            <h5>Receipient Profile</h5>
                        </div>
                        <div className="card-body">
                        <table className="table table-borderless">
                            <tbody>
                                <tr>
                                    <th>Receipient Name</th>
                                    <th>{data?.name}</th>
                                </tr>
                                <tr>
                                    <th>Address</th>
                                    <th>{data?.location}</th>
                                </tr>
                                <tr>
                                    <th>Organ Need</th>
                                    <th>{data?.organToBeTransplanted}</th>
                                </tr>
                                <tr>
                                    <th>Phone</th>
                                    <th>{data?.mobileNo}</th>
                                </tr>
                                <tr>
                                    <th>Gender</th>
                                    <th>{data?.gender}</th>
                                </tr>                                
                                <tr>
                                    <th>Organ Test</th>
                                    <th>{data?.organtest}</th>
                                </tr>                                
                                <tr>
                                    <th>Sugar</th>
                                    <th>{data?.sugar}</th>
                                </tr>                                
                                <tr>
                                    <th>Cholestrol</th>
                                    <th>{data?.cholestrol}</th>
                                </tr>                                
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </>
    )}

export default ReceipeintHome;