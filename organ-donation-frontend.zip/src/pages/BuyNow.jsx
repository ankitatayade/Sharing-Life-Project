import axios from "axios";
import { useEffect, useState } from "react";
import Header from "../components/Header";
import { useNavigate, useParams } from "react-router-dom"
import SideBar from "../components/SideBar";

function BuyNow(){
    const recid=sessionStorage.getItem("id")
    const [donorInfo,setdonorInfo]=useState()
    const navigate=useNavigate()
    const {id} = useParams("id")
    const [cardno,setcardno] = useState()
    useEffect(()=>{
        axios.get("http://localhost:8080/api/donors/"+id)
        .then(resp=>{
            setdonorInfo(resp.data)             
        })
        .catch(err=>{
            console.log(err)
        })
    },[])

    const processDonation  = e => {
        e.preventDefault()
        axios.post("http://localhost:8080/api/receipients/donation",{
            recid,
            donorid:id,
            amount:10000,
            cardno
        }).then(resp=>{
            alert("Donation processed successfully");
            navigate("/search")
        })
    }

    return (
        <>
        <Header/>   
        <div className="container-fluid">
            <div className="row">
                <div className="col-sm-2 bg-transparent p-0 border-right border-primary" style={{height:"calc(100vh - 80px)"}}>
                    <SideBar />
                </div>
                <div className="col-sm-5 p-3">
                    <div className="card shadow">
                        <div className="card-header">
                            <h5>Donor Details</h5>
                        </div>
                        <div className="card-body">
                        <table className="table table-borderless table-sm">
                            <tbody>
                                <tr>
                                    <th>Donor Name</th>
                                    <th>{donorInfo?.name}</th>
                                </tr>
                                <tr>
                                    <th>Address</th>
                                    <th>{donorInfo?.location}</th>
                                </tr>
                                <tr>
                                    <th>Date of Birth</th>
                                    <th>{donorInfo?.dateOfBirth}</th>
                                </tr>
                                <tr>
                                    <th>Register As</th>
                                    <th>{donorInfo?.registerAs}</th>
                                </tr>
                                <tr>
                                    <th>Mobile</th>
                                    <th>{donorInfo?.mobileNo}</th>
                                </tr>
                                <tr>
                                    <th>Organ Donated</th>
                                    <th>{donorInfo?.organToBeDonated}</th>
                                </tr>
                                <tr>
                                    <th>Hospital Name</th>
                                    <th>{donorInfo?.hospital.hospitalName}</th>
                                </tr>                                
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>

                <div className="col-sm-5 p-3">
                    <div className="card shadow">
                        <div className="card-header">
                            <h5>Payment Details</h5>
                        </div>
                        <form className="card-body" onSubmit={processDonation}>
                            <table className="table table-sm table-borderless">
                                <tbody>
                                    <tr>
                                        <th>Operation Cost</th>
                                        <th>Rs.10,000.00</th>
                                    </tr>
                                    <tr>
                                        <th>Card Number</th>
                                        <td>
                                            <input type="text" name="cardno" onChange={e=>setcardno(e.target.value)} maxLength={16} required className="form-control" placeholder="Card Number" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Name on Card</th>
                                        <td>
                                            <input type="text" required className="form-control" placeholder="Name on Card" />
                                        </td>
                                    </tr>
                                    <tr>
                                    <th>Expiry Date</th>
                                        <td><input type="month" required className="form-control" placeholder="Expiry" /></td>
                                    </tr>
                                    <tr>
                                    <th>CVV</th>
                                        <td>
                                            <input type="text" maxLength={3} required className="form-control" placeholder="CVV" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colSpan={2}>
                                            <button type="submit" className="btn btn-primary float-right">Pay Now</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </>
    )}

export default BuyNow;