import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import SideBar from "../components/SideBar";

function Hospitals(){
    const [data,setdata]=useState([])
    const navigate=useNavigate()
    const loadData=()=>{
        axios.get("http://localhost:8080/api/hospitals")
        .then(resp=>{
            setdata(resp.data)
            console.log(data)
        })
    }
    
    useEffect(()=>{
        loadData();
    },[])
    return(
        <>
        <Header/>
        <div className="container-fluid">
            <div className="row">
                <div className="col-sm-2 bg-transparent p-0 border-right border-primary" style={{height:"calc(100vh - 80px)"}}>
                    <SideBar />
                </div>
                <div className="col-sm-10">
                <a href="/addhospital" className="float-right btn btn-sm btn-primary m-2">Add New</a>
                    <h4 className="text-left p-2 border-bottom border-success">All Hospitals</h4>
                    <table className="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Company Name</th>
                        <th>Address</th>
                        <th>Website</th>
                        <th>Phone</th>
                        <th>Email ID</th>
                    </tr>
                </thead>
                <tbody>
                {data.map(x=>(
                    <tr key={x.id}>
                        <td>{x.id}</td>
                        <td>{x.hospitalName}</td>
                        <td>{x.address}</td>
                        <td>{x.hospitalContactNo}</td>
                        <td>{x.incharge}</td>
                        <td>{x.inchargeContactNo}</td>
                        
                    </tr>
                ))}
                </tbody>
            </table>
                </div>
            </div>
        </div>
        </>
    )
}

export default Hospitals;