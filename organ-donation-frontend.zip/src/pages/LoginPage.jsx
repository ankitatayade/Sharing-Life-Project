import axios from "axios";
import { useState } from "react"
import { useDispatch } from "react-redux"
import { useNavigate } from "react-router-dom";
import TopNavbar from "../components/TopNavbar";


function LoginPage(){
    const dispatch=useDispatch()
    const navigate=useNavigate()

    const [user,setUser]=useState({
        email:"",
        password:""
    })
    const [role,setrole] = useState()

    const handleInput=(e)=>{
        setUser({...user,[e.target.name]:e.target.value})
    }

    const handleSubmit=e=>{
        e.preventDefault()
        var url = "http://localhost:8080/api/donors/validate";
        if(role === "Admin"){
            url = "http://localhost:8080/api/hospitals/validate";
        }
        else if(role === "Receipients"){
            url = "http://localhost:8080/api/receipients/validate";
        }
        axios.post(url,user)
        .then(resp=>{
            let result=resp.data;
            console.log(resp.data)
            sessionStorage.setItem("userid",result.email)
            sessionStorage.setItem("uname",result.name)
            sessionStorage.setItem("role",role)
            sessionStorage.setItem("id",result.id) 
            sessionStorage.setItem("organ",result?.organToBeTransplanted)
            dispatch({type:'IsLoggedIn'})
            if(role === 'Admin')
                navigate("/dashboard")
            else if(role === "Donor")
                navigate("/uhome")                
            else if(role === "Receipients") 
                navigate("/rhome")
        })
        .catch(error=>{
            console.log("Error",error);
            alert("Invalid username or password");
        })                    
    }

    return(
        <div className="login">
            <TopNavbar/>            
            <div className="container pt-4">
                <div className="row">
                    <div className="col-sm-5 mx-auto" style={{paddingTop:"100px"}}>
                        <form className="card shadow mt-5"  onSubmit={handleSubmit}>
                            <div className="card-header bg-danger text-white">
                                <h5 className="text-center">Login Page</h5>
                            </div>                             
                            <div className="card-body">
                                <div className="form-group form-row">
                                    <label className="col-sm-4 col-form-label">User Id</label>
                                    <div className="col-sm-8">
                                    <input type="text" name="email" required className="form-control" placeholder="User Id"  value={user?.email} onChange={handleInput}/>
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 col-form-label">Password</label>
                                    <div className="col-sm-8">
                                    <input type="password" required className="form-control" name="password" placeholder="Password" value={user?.password} onChange={handleInput} />
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">Role</label>
                                    <div className="col-sm-8">
                                        <select name="role" required value={role} onChange={e=>setrole(e.target.value)} className="form-control form-control-sm">
                                            <option value="">Select Role</option>
                                            <option>Admin</option>     
                                            <option value="Donor">Donor/Guardian</option>     
                                            <option>Receipients</option>     
                                        </select>                                                               
                                    </div>                        
                                </div>
                                <button className="btn btn-primary float-right">Login</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    )
}

export default LoginPage;